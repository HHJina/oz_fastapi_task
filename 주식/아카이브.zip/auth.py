"""
보안 및 인증 (Authentication Layer)
- 비밀번호 해싱 및 JWT 토큰 검증 처리
"""

import os
from datetime import datetime, timedelta

from dotenv import load_dotenv
from fastapi import Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer
from jose import jwt
from passlib.context import CryptContext
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

import models
from database import get_db

# TODO: JWT 서명에 사용할 SECRET_KEY와 ALGORITHM(HS256)을 설정하세요
load_dotenv()
# .env에 시크릿키 저장, .gitignore 에 ..env 등록, 파일 안 올라가게.
SECRET_KEY = os.getenv("SECRET_KEY")
# DATABASE_URL = os.getenv("DATABASE_URL")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINS = 15

# 비밀번호 암호화 컨텍스트 (argon2 알고리즘 사용)
pwd_context = CryptContext(schemes=["argon2"], deprecated="auto")


def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + (timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINS))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


# 토큰 추출을 위한 OAuth2 설정
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")


async def get_current_user(
    token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)
):
    # credential_error = HTTPException(status_code = status.HTTP_401_UNAUTHORIZED)

    """토큰 해독 후 현재 로그인한 유저 정보를 반환하는 의존성 함수"""
    try:
        #  # jwt.decode를 사용하여 토큰을 해독하고 유저네임(sub)을 추출
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")

        # DB에서 해당 유저를 조회(select)하여 변수 user에 저장
        result = await db.execute(
            select(models.User).where(models.User.username == username)
        )
        user = result.scalar_one_or_none()

        # 유저가 존재하지 않을 경우 401 에러 발생
        if user is None:
            raise HTTPException(status_code=401, detail="인증 실패")

        return user

    except jwt.JWTError:
        # 토큰 무효화 등 예외 발생 시 401 에러 반환
        raise HTTPException(status_code=401, detail="유효하지 않은 토큰")
