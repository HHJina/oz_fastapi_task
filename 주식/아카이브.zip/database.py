"""
DB 설정 (Database Layer)
- 비동기 엔진 및 세션 생성
"""

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import declarative_base

DATABASE_URL = "sqlite+aiosqlite:///./trading_game.db"

# TODO: create_async_engine을 사용하여 비동기 엔진을 생성하세요
engine = create_async_engine(
    DATABASE_URL, echo=False, future=True  # SQL 로그 보고 싶으면 True
)

# TODO: async_sessionmaker를 사용하여 세션 로컬 클래스를 생성하세요
async_session = async_sessionmaker(
    bind=engine, expire_on_commit=False, class_=AsyncSession
)

# ORM 모델용 베이스 클래스
Base = declarative_base()


async def get_db():
    """비동기 DB 세션 생성 및 반환"""
    async with async_session() as session:
        try:
            yield session
        finally:
            await session.close()
